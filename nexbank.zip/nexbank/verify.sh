#!/bin/bash

BASE_URL="http://localhost:3000/api"

echo "1. Initializing Database..."
curl -X POST "$BASE_URL/setup"
echo -e "\n"

echo "2. Creating Customer..."
CUST=$(curl -s -X POST -H "Content-Type: application/json" -d '{"name":"Test User","cnic":"99999","contact":"0000"}' "$BASE_URL/customers")
echo $CUST
echo -e "\n"

echo "3. Creating Account..."
# Assuming Customer ID 1 exists from seed or above
ACC=$(curl -s -X POST -H "Content-Type: application/json" -d '{"customerId":1,"type":"Savings","balance":1000}' "$BASE_URL/accounts")
echo $ACC
echo -e "\n"

echo "4. Testing Deposit (COMMIT)..."
curl -X POST -H "Content-Type: application/json" -d '{"accountId":1,"amount":500}' "$BASE_URL/transactions/deposit"
echo -e "\n"

echo "5. Testing Withdrawal Error (ROLLBACK)..."
curl -X POST -H "Content-Type: application/json" -d '{"accountId":1,"amount":100,"simulateError":true}' "$BASE_URL/transactions/withdraw"
echo -e "\n"

echo "6. Testing Transfer (Atomicity)..."
curl -X POST -H "Content-Type: application/json" -d '{"fromAccount":1,"toAccount":2,"amount":200}' "$BASE_URL/transactions/transfer"
echo -e "\n"

echo "7. Testing Savepoint..."
curl -X POST -H "Content-Type: application/json" -d '{"accountId":1}' "$BASE_URL/transactions/savepoint"
echo -e "\n"

echo "Done. Please check database for final state."
