-- Drop tables if they exist to start fresh
DROP TABLE IF EXISTS AuditLog;
DROP TABLE IF EXISTS Transaction;
DROP TABLE IF EXISTS Account;
DROP TABLE IF EXISTS Customer;

-- Customer Table
CREATE TABLE Customer (
    CustomerID SERIAL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    CNIC VARCHAR(20) UNIQUE NOT NULL,
    Contact VARCHAR(20)
);

-- Account Table
CREATE TABLE Account (
    AccountNo INTEGER PRIMARY KEY,
    CustomerID INT REFERENCES Customer(CustomerID) ON DELETE CASCADE,
    Type VARCHAR(20) CHECK (Type IN ('Savings', 'Current')),
    Balance DECIMAL(15, 2) DEFAULT 0.00,
    Status VARCHAR(20) DEFAULT 'Active'
);

-- Transaction Table
CREATE TABLE Transaction (
    TransID SERIAL PRIMARY KEY,
    FromAccount INT REFERENCES Account(AccountNo) ON DELETE CASCADE,
    ToAccount INT REFERENCES Account(AccountNo) ON DELETE CASCADE,
    Amount DECIMAL(15, 2) NOT NULL,
    Type VARCHAR(20) CHECK (Type IN ('Deposit', 'Withdrawal', 'Transfer')),
    DateTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- AuditLog Table
CREATE TABLE AuditLog (
    LogID SERIAL PRIMARY KEY,
    Operation VARCHAR(50),
    TableAffected VARCHAR(50),
    UserAction VARCHAR(50),
    DateTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
