-- Insert Dummy Customers
INSERT INTO Customer (Name, CNIC, Contact) VALUES 
('Ali Khan', '12345-1234567-1', '0300-1234567'),
('Sara Ahmed', '12345-1234567-2', '0300-7654321');

-- Insert Dummy Accounts
INSERT INTO Account (AccountNo, CustomerID, Type, Balance) VALUES 
(45823, 1, 'Savings', 5000.00),
(98214, 2, 'Current', 10000.00);
