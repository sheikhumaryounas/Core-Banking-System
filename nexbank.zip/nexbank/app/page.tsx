'use client';

import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import CustomerForm from '@/app/components/CustomerForm';
import AccountForm from '@/app/components/AccountForm';
import TransactionForm from '@/app/components/TransactionForm';
import AuditLogViewer from '@/app/components/AuditLogViewer';

export default function Home() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [dashboardData, setDashboardData] = useState({
    totalCustomers: 0,
    totalAccounts: 0,
    totalHoldings: 0,
    recentTransactions: []
  });

  const fetchDashboardData = async () => {
    try {
      const res = await fetch('/api/dashboard');
      const data = await res.json();
      if (!data.error) {
        setDashboardData(data);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data');
    }
  };

  useEffect(() => {
    if (activeTab === 'dashboard') {
      fetchDashboardData();
    }
  }, [activeTab]);

  const initializeDB = async () => {
    if (confirm('Are you sure you want to reset the database? All data will be lost.')) {
      const res = await fetch('/api/setup', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        toast.success(data.message);
        window.location.reload();
      } else {
        toast.error(data.error);
      }
    }
  };

  return (
    <div className="min-h-screen p-6 bg-zinc-950 text-zinc-50 font-sans selection:bg-zinc-800">
      <header className="mb-8 flex flex-col items-center gap-6 text-center">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight text-zinc-50">
            NexBank
          </h1>
          <p className="text-zinc-400 text-sm">Core Banking System Simulation By Umar Younas,Hassaan Bahsir and Hassaan Mughal </p>
        </div>
        <button 
          onClick={initializeDB}
          className="h-9 px-4 py-2 bg-transparent border border-zinc-800 hover:bg-zinc-900 text-zinc-50 rounded-md text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-zinc-300"
        >
          Reset Database
        </button>
      </header>

      <div className="flex flex-wrap gap-1 mb-8 p-1 bg-zinc-900/50 rounded-lg border border-zinc-800 w-fit mx-auto">
        {['dashboard', 'customers', 'accounts', 'transactions', 'audit'].map((tab) => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all duration-200 ${
              activeTab === tab 
                ? 'bg-zinc-950 text-zinc-50 shadow-sm ring-1 ring-zinc-800' 
                : 'text-zinc-400 hover:text-zinc-50 hover:bg-zinc-800/50'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
            {tab === 'transactions' && <span className="hidden md:inline ml-1 opacity-75">(TCL)</span>}
            {tab === 'audit' && <span className="hidden md:inline ml-1 opacity-75">(Logs)</span>}
          </button>
        ))}
      </div>

      <main className="bg-zinc-900/20 p-6 rounded-xl border border-zinc-800 shadow-sm min-h-[500px] relative overflow-hidden">
        <div className="relative z-10">
          {activeTab === 'dashboard' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Total Customers Card */}
                <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm p-6 hover:bg-zinc-900/50 transition-all duration-300 group">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-2 bg-zinc-900 rounded-lg group-hover:bg-zinc-800 transition-colors border border-zinc-800">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-zinc-400 group-hover:text-zinc-50 transition-colors"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                    <span className="text-xs font-medium text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20">
                      +12%
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-zinc-400">Total Customers</p>
                    <h3 className="text-2xl font-bold text-zinc-50 mt-1">{dashboardData.totalCustomers}</h3>
                  </div>
                </div>

                {/* Total Accounts Card */}
                <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm p-6 hover:bg-zinc-900/50 transition-all duration-300 group">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-2 bg-zinc-900 rounded-lg group-hover:bg-zinc-800 transition-colors border border-zinc-800">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-zinc-400 group-hover:text-zinc-50 transition-colors"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>
                    </div>
                    <span className="text-xs font-medium text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20">
                      +5%
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-zinc-400">Active Accounts</p>
                    <h3 className="text-2xl font-bold text-zinc-50 mt-1">{dashboardData.totalAccounts}</h3>
                  </div>
                </div>

                {/* Total Holdings Card */}
                <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm p-6 hover:bg-zinc-900/50 transition-all duration-300 group">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-2 bg-zinc-900 rounded-lg group-hover:bg-zinc-800 transition-colors border border-zinc-800">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-zinc-400 group-hover:text-zinc-50 transition-colors"><line x1="12" x2="12" y1="2" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    </div>
                    <span className="text-xs font-medium text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20">
                      +8.2%
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-zinc-400">Total Holdings</p>
                    <h3 className="text-2xl font-bold text-zinc-50 mt-1">${dashboardData.totalHoldings.toLocaleString()}</h3>
                  </div>
                </div>
              </div>

              {/* Recent Activity */}
              <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm overflow-hidden">
                <div className="flex flex-col space-y-1.5 p-6 border-b border-zinc-800/50 bg-zinc-900/20">
                  <h3 className="font-semibold leading-none tracking-tight">Recent Activity</h3>
                  <p className="text-sm text-zinc-400">Latest transactions across all accounts.</p>
                </div>
                <div className="p-0">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs text-zinc-400 uppercase bg-zinc-900/50 border-b border-zinc-800">
                      <tr>
                        <th className="px-6 py-3 font-medium">ID</th>
                        <th className="px-6 py-3 font-medium">Type</th>
                        <th className="px-6 py-3 font-medium">Account</th>
                        <th className="px-6 py-3 font-medium text-right">Amount</th>
                        <th className="px-6 py-3 font-medium">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800">
                      {dashboardData.recentTransactions.map((t: any) => (
                        <tr key={t.transid} className="hover:bg-zinc-900/50 transition-colors group">
                          <td className="px-6 py-4 font-mono text-xs text-zinc-500">#{t.transid}</td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center rounded-md px-2.5 py-0.5 text-xs font-medium border ${
                              t.type === 'Deposit' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 
                              t.type === 'Withdraw' ? 'bg-rose-500/10 text-rose-500 border-rose-500/20' : 
                              'bg-blue-500/10 text-blue-500 border-blue-500/20'
                            }`}>
                              {t.type}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-zinc-300">
                            {t.type === 'Deposit' ? `Acc: ${t.toaccount}` : 
                             t.type === 'Withdrawal' ? `Acc: ${t.fromaccount}` : 
                             `${t.fromaccount} → ${t.toaccount}`}
                          </td>
                          <td className={`px-6 py-4 text-right font-mono font-medium ${
                            t.type === 'Deposit' ? 'text-emerald-500' : 'text-rose-500'
                          }`}>
                            {t.type === 'Deposit' ? '+' : '-'}${parseFloat(t.amount).toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-zinc-500 text-xs">
                            {new Date(t.datetime).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                      {dashboardData.recentTransactions.length === 0 && (
                        <tr>
                          <td colSpan={5} className="px-6 py-8 text-center text-zinc-500">
                            No recent transactions found.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          {activeTab === 'customers' && <CustomerForm />}
          {activeTab === 'accounts' && <AccountForm />}
          {activeTab === 'transactions' && <TransactionForm />}
          {activeTab === 'audit' && <AuditLogViewer />}
        </div>
      </main>
    </div>
  );
}
