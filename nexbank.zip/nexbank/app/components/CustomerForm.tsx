'use client';

import { useState, useEffect } from 'react';
import { toast } from 'sonner';

export default function CustomerForm() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [formData, setFormData] = useState({ name: '', cnic: '', contact: '' });
  const [loading, setLoading] = useState(false);

  const fetchCustomers = async () => {
    const res = await fetch('/api/customers');
    const data = await res.json();
    if (Array.isArray(data)) {
      setCustomers(data);
    } else {
      console.error('Failed to fetch customers:', data);
      setCustomers([]);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this customer?')) return;
    try {
      const res = await fetch(`/api/customers?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Customer deleted successfully');
        fetchCustomers();
      } else {
        const data = await res.json();
        toast.error('Error: ' + data.error);
      }
    } catch (error) {
      toast.error('Failed to delete customer');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    const cnicRegex = /^\d{13}$/;
    const phoneRegex = /^03\d{9}$/;

    if (!cnicRegex.test(formData.cnic)) {
      toast.error('CNIC must be exactly 13 digits (numbers only).');
      return;
    }

    if (!phoneRegex.test(formData.contact)) {
      toast.error('Contact number must be 11 digits and start with 03.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setFormData({ name: '', cnic: '', contact: '' });
        fetchCustomers();
        toast.success('Customer created successfully');
      } else {
        const data = await res.json();
        toast.error('Error: ' + data.error);
      }
    } catch (error) {
      toast.error('Failed to create customer');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-zinc-50">Customer Management</h2>
        <span className="px-2.5 py-0.5 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-medium">
          {customers.length} Customers
        </span>
      </div>
      
      <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm overflow-hidden">
        <div className="flex flex-col space-y-1.5 p-6 border-b border-zinc-800/50 bg-zinc-900/20">
            <h3 className="font-semibold leading-none tracking-tight">Add New Customer</h3>
            <p className="text-sm text-zinc-400">Create a profile for a new bank customer.</p>
        </div>
        <div className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Full Name</label>
                    <input
                    type="text"
                    placeholder="e.g. John Doe"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                    required
                    />
                </div>
                <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">CNIC Number</label>
                    <input
                    type="number"
                    placeholder="e.g. 1234512345671"
                    value={formData.cnic}
                    onChange={(e) => setFormData({ ...formData, cnic: e.target.value })}
                    className="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                    required
                    />
                </div>
                <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Contact Number</label>
                    <input
                    type="number"
                    placeholder="e.g. 03001234567"
                    value={formData.contact}
                    onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                    className="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                    required
                    />
                </div>
                </div>
                <div className="flex justify-end pt-2">
                <button 
                    type="submit" 
                    disabled={loading}
                    className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-zinc-50 text-zinc-950 hover:bg-zinc-200 h-10 px-4 py-2 shadow-sm"
                >
                    {loading ? 'Creating...' : 'Add Customer'}
                </button>
                </div>
            </form>
        </div>
      </div>

      <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 overflow-hidden shadow-sm">
        <table className="min-w-full w-full text-sm text-left">
          <thead>
            <tr className="border-b border-zinc-800 bg-zinc-900/50">
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">ID</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Name</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">CNIC</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Contact</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {customers.map((c) => (
              <tr key={c.customerid} className="hover:bg-zinc-900/50 transition-colors">
                <td className="p-4 text-zinc-500 font-mono text-xs">#{c.customerid}</td>
                <td className="p-4 text-zinc-50 font-medium">{c.name}</td>
                <td className="p-4 text-zinc-400">{c.cnic}</td>
                <td className="p-4 text-zinc-400">{c.contact}</td>
                <td className="p-4 text-right">
                  <button 
                    onClick={() => handleDelete(c.customerid)}
                    className="text-xs text-red-500 hover:text-red-400 hover:bg-red-500/10 px-2 py-1 rounded transition-colors"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {customers.length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-zinc-500 text-sm">
                  No customers found. Add one above.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
