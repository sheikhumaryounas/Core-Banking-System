'use client';

import { useState, useEffect, FormEvent } from 'react';
import { toast } from 'sonner';

export default function TransactionForm() {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [logs, setLogs] = useState<{ id: number, message: string }[]>([]);
  const [transactionType, setTransactionType] = useState('deposit');
  
  // Deposit State
  const [depositData, setDepositData] = useState({ accountId: '', amount: '' });
  
  // Withdraw State
  const [withdrawData, setWithdrawData] = useState({ accountId: '', amount: '' });

  // Transfer State
  const [transferData, setTransferData] = useState({ fromAccount: '', toAccount: '', amount: '' });

  // Savepoint State
  const [savepointData, setSavepointData] = useState({ accountId: '' });

  const fetchAccounts = async () => {
    const res = await fetch('/api/accounts');
    setAccounts(await res.json());
  };

  useEffect(() => {
    fetchAccounts();
  }, []);

  const addLog = (msg: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [{ id: Date.now() + Math.random(), message: `${timestamp}: ${msg}` }, ...prev]);
  };

  const handleDeposit = async (e: FormEvent) => {
    e.preventDefault();
    addLog(`Starting Deposit Transaction (COMMIT)...`);
    try {
      const res = await fetch('/api/transactions/deposit', {
        method: 'POST',
        body: JSON.stringify(depositData),
      });
      const data = await res.json();
      if (res.ok) {
        addLog(`SUCCESS: ${data.message}`);
        toast.success(data.message);
        setDepositData({ accountId: '', amount: '' });
      } else {
        addLog(`FAILED: ${data.error}`);
        toast.error(data.error);
      }
      await fetchAccounts();
    } catch (error: any) {
      addLog(`ERROR: ${error.message}`);
      toast.error(error.message);
    }
  };

  const handleWithdraw = async (e: FormEvent) => {
    e.preventDefault();
    addLog(`Starting Withdrawal Transaction (ROLLBACK on Error)...`);
    try {
      const res = await fetch('/api/transactions/withdraw', {
        method: 'POST',
        body: JSON.stringify(withdrawData),
      });
      const data = await res.json();
      if (res.ok) {
        addLog(`SUCCESS: ${data.message}`);
        toast.success(data.message);
        setWithdrawData({ accountId: '', amount: '' });
      } else {
        addLog(`FAILED (Rolled Back): ${data.error}`);
        toast.error(data.error);
      }
      await fetchAccounts();
    } catch (error: any) {
      addLog(`ERROR: ${error.message}`);
      toast.error(error.message);
    }
  };

  const handleTransfer = async (e: FormEvent) => {
    e.preventDefault();
    
    if (transferData.fromAccount === transferData.toAccount) {
      toast.error('Cannot transfer to the same account.');
      return;
    }

    addLog(`Starting Transfer Transaction (Atomicity)...`);
    try {
      const res = await fetch('/api/transactions/transfer', {
        method: 'POST',
        body: JSON.stringify(transferData),
      });
      const data = await res.json();
      if (res.ok) {
        addLog(`SUCCESS: ${data.message}`);
        toast.success(data.message);
        setTransferData({ fromAccount: '', toAccount: '', amount: '' });
      } else {
        addLog(`FAILED (Rolled Back): ${data.error}`);
        toast.error(data.error);
      }
      await fetchAccounts();
    } catch (error: any) {
      addLog(`ERROR: ${error.message}`);
      toast.error(error.message);
    }
  };

  const handleSavepoint = async (e: FormEvent) => {
    e.preventDefault();
    addLog(`Starting Service Fee Transaction (SAVEPOINT)...`);
    try {
      const res = await fetch('/api/transactions/savepoint', {
        method: 'POST',
        body: JSON.stringify(savepointData),
      });
      const data = await res.json();
      if (res.ok) {
        addLog(`SUCCESS: ${data.message}`);
        toast.success(data.message);
        setSavepointData({ accountId: '' });
      } else {
        addLog(`FAILED: ${data.error}`);
        toast.error(data.error);
      }
      await fetchAccounts();
    } catch (error: any) {
      addLog(`ERROR: ${error.message}`);
      toast.error(error.message);
    }
  };




  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        {/* Shadcn-style Tabs List */}
        <div className="grid w-full grid-cols-4 bg-zinc-900/50 p-1 rounded-lg border border-zinc-800/50">
            {['deposit', 'withdraw', 'transfer', 'savepoint'].map(type => (
                <button
                    key={type}
                    onClick={() => setTransactionType(type)}
                    className={`
                        flex items-center justify-center py-2 text-sm font-medium rounded-md transition-all duration-200
                        ${transactionType === type 
                            ? 'bg-zinc-950 text-zinc-50 shadow-sm ring-1 ring-zinc-800' 
                            : 'text-zinc-400 hover:text-zinc-50 hover:bg-zinc-800/50'
                        }
                    `}
                >
                    {type === 'savepoint' ? 'Service Fee' : type.charAt(0).toUpperCase() + type.slice(1)}
                </button>
            ))}
        </div>

        {/* Transaction Card */}
        <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm overflow-hidden">
            <div className="flex flex-col space-y-1.5 p-6 border-b border-zinc-800/50 bg-zinc-900/20">
                <h3 className="font-semibold leading-none tracking-tight flex items-center gap-2 text-lg">
                    {transactionType === 'deposit' && <span className="flex h-2 w-2 rounded-full bg-emerald-500" />}
                    {transactionType === 'withdraw' && <span className="flex h-2 w-2 rounded-full bg-rose-500" />}
                    {transactionType === 'transfer' && <span className="flex h-2 w-2 rounded-full bg-blue-500" />}
                    {transactionType === 'savepoint' && <span className="flex h-2 w-2 rounded-full bg-amber-500" />}
                    
                    {transactionType === 'deposit' && 'Deposit Funds'}
                    {transactionType === 'withdraw' && 'Withdraw Funds'}
                    {transactionType === 'transfer' && 'Transfer Funds'}
                    {transactionType === 'savepoint' && 'Service Fee Deduction'}
                </h3>
                <p className="text-sm text-zinc-400">
                    {transactionType === 'deposit' && 'Add funds to an account. Uses SQL COMMIT to persist changes.'}
                    {transactionType === 'withdraw' && 'Deduct funds from an account. Uses ROLLBACK if insufficient funds.'}
                    {transactionType === 'transfer' && 'Move funds between accounts. Ensures Atomicity (all or nothing).'}
                    {transactionType === 'savepoint' && 'Apply a fee with a SAVEPOINT. Rolls back only the fee if it causes negative balance.'}
                </p>
            </div>
            
            <div className="p-6">
                {transactionType === 'deposit' && (
                    <form onSubmit={handleDeposit} className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <div className="space-y-2">
                            <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Account</label>
                            <select 
                                className="flex h-10 w-full items-center justify-between rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                                value={depositData.accountId}
                                onChange={e => setDepositData({...depositData, accountId: e.target.value})}
                                required
                            >
                                <option value="" className="bg-zinc-950">Select Account</option>
                                {accounts.map(a => <option key={a.accountno} value={a.accountno} className="bg-zinc-950">#{a.accountno} - ${a.balance}</option>)}
                            </select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Amount</label>
                            <input 
                                type="number" 
                                placeholder="0.00" 
                                className="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                                value={depositData.amount}
                                onChange={e => setDepositData({...depositData, amount: e.target.value})}
                                required
                            />
                        </div>
                        <button type="submit" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-zinc-50 text-zinc-950 hover:bg-zinc-200 h-10 px-4 py-2 w-full mt-2">
                            Confirm Deposit
                        </button>
                    </form>
                )}

                {transactionType === 'withdraw' && (
                    <form onSubmit={handleWithdraw} className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <div className="space-y-2">
                            <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Account</label>
                            <select 
                                className="flex h-10 w-full items-center justify-between rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                                value={withdrawData.accountId}
                                onChange={e => setWithdrawData({...withdrawData, accountId: e.target.value})}
                                required
                            >
                                <option value="" className="bg-zinc-950">Select Account</option>
                                {accounts.map(a => <option key={a.accountno} value={a.accountno} className="bg-zinc-950">#{a.accountno} - ${a.balance}</option>)}
                            </select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Amount</label>
                            <input 
                                type="number" 
                                placeholder="0.00" 
                                className="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                                value={withdrawData.amount}
                                onChange={e => setWithdrawData({...withdrawData, amount: e.target.value})}
                                required
                            />
                        </div>
                        <button type="submit" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-zinc-50 text-zinc-950 hover:bg-zinc-200 h-10 px-4 py-2 w-full mt-2">
                            Confirm Withdrawal
                        </button>
                    </form>
                )}

                {transactionType === 'transfer' && (
                    <form onSubmit={handleTransfer} className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">From Account</label>
                                <select 
                                    className="flex h-10 w-full items-center justify-between rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                                    value={transferData.fromAccount}
                                    onChange={e => setTransferData({...transferData, fromAccount: e.target.value})}
                                    required
                                >
                                    <option value="" className="bg-zinc-950">Select</option>
                                    {accounts.map(a => <option key={a.accountno} value={a.accountno} className="bg-zinc-950">#{a.accountno}</option>)}
                                </select>
                            </div>
                            <div className="space-y-2">
                                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">To Account</label>
                                <select 
                                    className="flex h-10 w-full items-center justify-between rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                                    value={transferData.toAccount}
                                    onChange={e => setTransferData({...transferData, toAccount: e.target.value})}
                                    required
                                >
                                    <option value="" className="bg-zinc-950">Select</option>
                                    {accounts.map(a => <option key={a.accountno} value={a.accountno} className="bg-zinc-950">#{a.accountno}</option>)}
                                </select>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Amount</label>
                            <input 
                                type="number" 
                                placeholder="0.00" 
                                className="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                                value={transferData.amount}
                                onChange={e => setTransferData({...transferData, amount: e.target.value})}
                                required
                            />
                        </div>
                        <button type="submit" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-zinc-50 text-zinc-950 hover:bg-zinc-200 h-10 px-4 py-2 w-full mt-2">
                            Execute Transfer
                        </button>
                    </form>
                )}

                {transactionType === 'savepoint' && (
                    <form onSubmit={handleSavepoint} className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <div className="space-y-2">
                            <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Account</label>
                            <select 
                                className="flex h-10 w-full items-center justify-between rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                                value={savepointData.accountId}
                                onChange={e => setSavepointData({...savepointData, accountId: e.target.value})}
                                required
                            >
                                <option value="" className="bg-zinc-950">Select Account</option>
                                {accounts.map(a => <option key={a.accountno} value={a.accountno} className="bg-zinc-950">#{a.accountno} - ${a.balance}</option>)}
                            </select>
                        </div>
                        <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-500 text-sm">
                            <p className="font-medium">Notice</p>
                            <p className="opacity-90 mt-1">This will attempt to deduct a $10 service fee. If the account balance drops below zero, the transaction will be rolled back to the SAVEPOINT, effectively waiving the fee.</p>
                        </div>
                        <button type="submit" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-zinc-50 text-zinc-950 hover:bg-zinc-200 h-10 px-4 py-2 w-full mt-2">
                            Apply Service Fee
                        </button>
                    </form>
                )}
            </div>
        </div>
      </div>

      {/* Logs Panel */}
      <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm flex flex-col h-[600px] overflow-hidden">
        <div className="flex flex-col space-y-1.5 p-6 pb-4 border-b border-zinc-800/50 bg-zinc-900/20">
            <h3 className="font-semibold leading-none tracking-tight">Transaction Logs</h3>
            <p className="text-sm text-zinc-400">Real-time audit trail of your actions.</p>
        </div>
        <div className="p-4 flex-1 overflow-y-auto space-y-3 bg-zinc-950/30">
          {logs.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-zinc-500 space-y-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="opacity-50"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                  <p className="text-xs">No logs generated yet.</p>
              </div>
          )}
          {logs.map((log) => (
            <div key={log.id} className="flex gap-3 text-sm animate-in fade-in slide-in-from-left-2 duration-300 group">
              <div className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${
                  log.message.includes('SUCCESS') ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 
                  log.message.includes('FAILED') ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]' : 
                  'bg-blue-500'
              }`} />
              <div className="space-y-0.5">
                <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider">{log.message.split(': ')[0]}</p>
                <p className="text-zinc-300 text-xs leading-relaxed">{log.message.split(': ').slice(1).join(': ')}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
