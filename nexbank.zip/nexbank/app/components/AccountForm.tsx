'use client';

import { useState, useEffect } from 'react';
import { toast } from 'sonner';

export default function AccountForm() {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [formData, setFormData] = useState({ customerId: '', accountType: 'Savings', balance: '' });
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    const accRes = await fetch('/api/accounts');
    const custRes = await fetch('/api/customers');
    setAccounts(await accRes.json());
    setCustomers(await custRes.json());
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this account?')) return;
    try {
      const res = await fetch(`/api/accounts?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Account deleted successfully');
        fetchData();
      } else {
        const data = await res.json();
        toast.error('Error: ' + data.error);
      }
    } catch (error) {
      toast.error('Failed to delete account');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerId: formData.customerId,
          type: formData.accountType,
          balance: formData.balance
        }),
      });
      if (res.ok) {
        setFormData({ customerId: '', accountType: 'Savings', balance: '' });
        fetchData();
        toast.success('Account created successfully');
      } else {
        const data = await res.json();
        toast.error('Error: ' + data.error);
      }
    } catch (error) {
      toast.error('Failed to create account');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-zinc-50">Account Management</h2>
        <span className="px-2.5 py-0.5 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-medium">
          {accounts.length} Accounts
        </span>
      </div>

      <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm overflow-hidden">
        <div className="flex flex-col space-y-1.5 p-6 border-b border-zinc-800/50 bg-zinc-900/20">
            <h3 className="font-semibold leading-none tracking-tight">Create New Account</h3>
            <p className="text-sm text-zinc-400">Open a new bank account for an existing customer.</p>
        </div>
        <div className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Customer</label>
                    <select 
                    value={formData.customerId}
                    onChange={(e) => setFormData({ ...formData, customerId: e.target.value })}
                    className="flex h-10 w-full items-center justify-between rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                    required
                    >
                    <option value="" className="bg-zinc-950">Select Customer</option>
                    {customers.map((c) => (
                        <option key={c.customerid} value={c.customerid} className="bg-zinc-950">
                        {c.name} (ID: {c.customerid})
                        </option>
                    ))}
                    </select>
                </div>
                <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Account Type</label>
                    <select 
                    value={formData.accountType}
                    onChange={(e) => setFormData({ ...formData, accountType: e.target.value })}
                    className="flex h-10 w-full items-center justify-between rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                    <option value="Savings" className="bg-zinc-950">Savings</option>
                    <option value="Current" className="bg-zinc-950">Current</option>
                    </select>
                </div>
                <div className="space-y-2">
                    <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-zinc-300">Initial Deposit</label>
                    <input
                    type="number"
                    placeholder="0.00"
                    value={formData.balance}
                    onChange={(e) => setFormData({ ...formData, balance: e.target.value })}
                    className="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:ring-offset-2 focus:ring-offset-zinc-950 disabled:cursor-not-allowed disabled:opacity-50"
                    required
                    />
                </div>
                </div>
                <div className="flex justify-end pt-2">
                <button 
                    type="submit" 
                    disabled={loading}
                    className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-zinc-50 text-zinc-950 hover:bg-zinc-200 h-10 px-4 py-2 shadow-sm"
                >
                    {loading ? 'Creating...' : 'Create Account'}
                </button>
                </div>
            </form>
        </div>
      </div>

      <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 overflow-hidden shadow-sm">
        <table className="min-w-full w-full text-sm text-left">
          <thead>
            <tr className="border-b border-zinc-800 bg-zinc-900/50">
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Account No</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Customer ID</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Type</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Balance</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {accounts.map((acc) => (
              <tr key={acc.accountno} className="hover:bg-zinc-900/50 transition-colors">
                <td className="p-4 text-zinc-500 font-mono text-xs">#{acc.accountno}</td>
                <td className="p-4 text-zinc-400">#{acc.customerid}</td>
                <td className="p-4">
                    <span className={`inline-flex items-center rounded-md px-2 py-1 text-xs font-medium border ${
                        acc.type === 'Savings' ? 'bg-blue-500/10 text-blue-500 border-blue-500/20' :
                        'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                    }`}>
                        {acc.type}
                    </span>
                </td>
                <td className="p-4 text-zinc-50 font-medium">${acc.balance}</td>
                <td className="p-4 text-right">
                  <button 
                    onClick={() => handleDelete(acc.accountno)}
                    className="text-xs text-red-500 hover:text-red-400 hover:bg-red-500/10 px-2 py-1 rounded transition-colors"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {accounts.length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-zinc-500 text-sm">
                  No accounts found. Create one above.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
