'use client';

import { useState, useEffect } from 'react';

export default function AuditLogViewer() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/audit-logs');
      const data = await res.json();
      if (!data.error) {
        setLogs(data);
      }
    } catch (error) {
      console.error('Failed to fetch audit logs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  return (
    <div className="rounded-3xl border border-zinc-800 bg-zinc-950/50 text-zinc-50 shadow-sm overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b border-zinc-800/50 bg-zinc-900/20">
        <div className="flex flex-col space-y-1.5">
            <h3 className="font-semibold leading-none tracking-tight">Audit Logs</h3>
            <p className="text-sm text-zinc-400">System-wide audit trail for security and compliance.</p>
        </div>
        <div className="flex gap-2 items-center">
            <span className="px-2.5 py-0.5 rounded-md bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs font-medium">
            {logs.length} Records
            </span>
            <button 
                onClick={fetchLogs}
                className="inline-flex items-center justify-center rounded-md text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-7 px-3 bg-zinc-50 text-zinc-900 hover:bg-zinc-200"
            >
                Refresh
            </button>
        </div>
      </div>

      <div className="p-0">
        <table className="min-w-full w-full text-sm text-left">
          <thead>
            <tr className="border-b border-zinc-800 bg-zinc-900/50">
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Log ID</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Operation</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Table Affected</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">User / Action</th>
              <th className="h-10 px-4 align-middle font-medium text-zinc-400">Date Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {logs.map((log) => (
              <tr key={log.logid} className="hover:bg-zinc-900/50 transition-colors">
                <td className="p-4 text-zinc-500 font-mono text-xs">#{log.logid}</td>
                <td className="p-4 text-zinc-50">
                    <span className={`inline-flex items-center rounded-md px-2 py-1 text-xs font-medium border ${
                        log.operation === 'INSERT' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' :
                        log.operation === 'UPDATE' ? 'bg-blue-500/10 text-blue-500 border-blue-500/20' :
                        log.operation === 'DELETE' ? 'bg-rose-500/10 text-rose-500 border-rose-500/20' :
                        'bg-zinc-500/10 text-zinc-500 border-zinc-500/20'
                    }`}>
                        {log.operation}
                    </span>
                </td>
                <td className="p-4 text-zinc-300 text-sm">{log.tableaffected}</td>
                <td className="p-4 text-zinc-300 text-sm">{log.useraction}</td>
                <td className="p-4 text-zinc-500 text-xs">{new Date(log.datetime).toLocaleString()}</td>
              </tr>
            ))}
            {logs.length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-zinc-500 text-sm">
                  {loading ? 'Loading logs...' : 'No audit logs found.'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
