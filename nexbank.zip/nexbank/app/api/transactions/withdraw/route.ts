import { NextResponse } from 'next/server';
import pool from '@/lib/db';

export async function POST(request: Request) {
  const client = await pool.connect();
  try {
    const { accountId, amount } = await request.json();
    
    await client.query('BEGIN'); // Start Transaction

    // Check Balance
    const res = await client.query('SELECT Balance FROM Account WHERE AccountNo = $1', [accountId]);
    if (res.rows.length === 0) throw new Error('Account not found');
    
    const currentBalance = parseFloat(res.rows[0].balance);

    if (currentBalance < amount) {
        throw new Error('Insufficient funds');
    }

    // Deduct Balance
    await client.query(
      'UPDATE Account SET Balance = Balance - $1 WHERE AccountNo = $2',
      [amount, accountId]
    );

    // Log Transaction
    await client.query(
      'INSERT INTO Transaction (FromAccount, Amount, Type) VALUES ($1, $2, $3)',
      [accountId, amount, 'Withdrawal']
    );

    await client.query('COMMIT'); // Commit Transaction
    return NextResponse.json({ message: 'Withdrawal successful' }, { status: 200 });
  } catch (error: any) {
    await client.query('ROLLBACK'); // Rollback on error
    return NextResponse.json({ error: error.message }, { status: 400 });
  } finally {
    client.release();
  }
}
