import { NextResponse } from 'next/server';
import pool from '@/lib/db';

export async function POST(request: Request) {
  const client = await pool.connect();
  try {
    const { accountId } = await request.json();
    const FEE = 10.00;
    
    await client.query('BEGIN'); // Start Transaction

    // Step 1: Log the attempt (This will persist even if we rollback to savepoint later, IF we don't rollback the whole thing)
    // Actually, if we rollback to savepoint, everything after savepoint is undone.
    // To keep a log of "Attempted", we should insert it BEFORE the savepoint.
    
    await client.query(
      'INSERT INTO AuditLog (Operation, TableAffected, UserAction) VALUES ($1, $2, $3)',
      ['INFO', 'Account', `Attempting service fee deduction for Account ${accountId}`]
    );

    await client.query('SAVEPOINT before_fee'); // Create Savepoint

    // Step 2: Deduct Fee
    await client.query(
      'UPDATE Account SET Balance = Balance - $1 WHERE AccountNo = $2',
      [FEE, accountId]
    );

    // Step 3: Check Balance
    const res = await client.query('SELECT Balance FROM Account WHERE AccountNo = $1', [accountId]);
    const newBalance = parseFloat(res.rows[0].balance);

    if (newBalance < 0) {
        // Balance went negative, undo the fee deduction
        await client.query('ROLLBACK TO before_fee');
        
        await client.query(
            'INSERT INTO AuditLog (Operation, TableAffected, UserAction) VALUES ($1, $2, $3)',
            ['WARNING', 'Account', `Fee waived for Account ${accountId} due to low balance`]
        );
        
        await client.query('COMMIT');
        return NextResponse.json({ message: 'Balance too low for fee. Deduction rolled back (Fee Waived).' }, { status: 200 });
    } else {
        // Balance is fine, confirm deduction
        await client.query(
            'INSERT INTO AuditLog (Operation, TableAffected, UserAction) VALUES ($1, $2, $3)',
            ['SUCCESS', 'Account', `Service fee of $${FEE} applied to Account ${accountId}`]
        );
        
        await client.query('COMMIT');
        return NextResponse.json({ message: `Service fee of $${FEE} deducted successfully.` }, { status: 200 });
    }
  } catch (error: any) {
    await client.query('ROLLBACK'); // Rollback on error
    return NextResponse.json({ error: error.message }, { status: 500 });
  } finally {
    client.release();
  }
}
