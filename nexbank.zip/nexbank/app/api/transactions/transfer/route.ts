import { NextResponse } from 'next/server';
import pool from '@/lib/db';

export async function POST(request: Request) {
  const client = await pool.connect();
  try {
    const { fromAccount, toAccount, amount } = await request.json();
    
    if (fromAccount === toAccount) {
        return NextResponse.json({ error: 'Cannot transfer to the same account' }, { status: 400 });
    }

    await client.query('BEGIN'); // Start Transaction

    // Check Sender Balance
    const res = await client.query('SELECT Balance FROM Account WHERE AccountNo = $1', [fromAccount]);
    if (res.rows.length === 0) throw new Error('Sender account not found');
    
    const senderBalance = parseFloat(res.rows[0].balance);
    if (senderBalance < amount) {
        throw new Error('Insufficient funds');
    }

    // Debit Sender
    await client.query(
      'UPDATE Account SET Balance = Balance - $1 WHERE AccountNo = $2',
      [amount, fromAccount]
    );

    // Credit Receiver
    await client.query(
      'UPDATE Account SET Balance = Balance + $1 WHERE AccountNo = $2',
      [amount, toAccount]
    );

    // Log Transaction
    await client.query(
      'INSERT INTO Transaction (FromAccount, ToAccount, Amount, Type) VALUES ($1, $2, $3, $4)',
      [fromAccount, toAccount, amount, 'Transfer']
    );

    await client.query('COMMIT'); // Commit Transaction
    return NextResponse.json({ message: 'Transfer successful' }, { status: 200 });
  } catch (error: any) {
    await client.query('ROLLBACK'); // Rollback on error
    return NextResponse.json({ error: error.message }, { status: 400 });
  } finally {
    client.release();
  }
}
