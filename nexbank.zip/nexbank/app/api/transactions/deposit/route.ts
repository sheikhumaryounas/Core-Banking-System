import { NextResponse } from 'next/server';
import pool from '@/lib/db';

export async function POST(request: Request) {
  const client = await pool.connect();
  try {
    const { accountId, amount } = await request.json();
    
    await client.query('BEGIN'); // Start Transaction

    // Update Balance
    await client.query(
      'UPDATE Account SET Balance = Balance + $1 WHERE AccountNo = $2',
      [amount, accountId]
    );

    // Log Transaction
    await client.query(
      'INSERT INTO Transaction (ToAccount, Amount, Type) VALUES ($1, $2, $3)',
      [accountId, amount, 'Deposit']
    );

    // Audit Log
    await client.query(
      'INSERT INTO AuditLog (Operation, TableAffected, UserAction) VALUES ($1, $2, $3)',
      ['UPDATE', 'Account', 'Deposit Performed']
    );

    await client.query('COMMIT'); // Commit Transaction
    return NextResponse.json({ message: 'Deposit successful' }, { status: 200 });
  } catch (error: any) {
    await client.query('ROLLBACK'); // Rollback on error
    return NextResponse.json({ error: error.message }, { status: 500 });
  } finally {
    client.release();
  }
}
