import { NextResponse } from 'next/server';
import pool from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { customerId, type, balance } = await request.json();
    const client = await pool.connect();
    try {
      // Check for existing account of same type
      const existing = await client.query(
        'SELECT * FROM Account WHERE CustomerID = $1 AND Type = $2',
        [customerId, type]
      );

      if (existing.rows.length > 0) {
        return NextResponse.json(
          { error: `Customer already has a ${type} account` }, 
          { status: 400 }
        );
      }

      // Generate random 5-digit account number
      let accountNo;
      let isUnique = false;
      while (!isUnique) {
        accountNo = Math.floor(10000 + Math.random() * 90000);
        const check = await client.query('SELECT AccountNo FROM Account WHERE AccountNo = $1', [accountNo]);
        if (check.rows.length === 0) isUnique = true;
      }

      const result = await client.query(
        'INSERT INTO Account (AccountNo, CustomerID, Type, Balance) VALUES ($1, $2, $3, $4) RETURNING *',
        [accountNo, customerId, type, balance]
      );
      return NextResponse.json(result.rows[0], { status: 201 });
    } finally {
      client.release();
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function GET() {
    try {
        const client = await pool.connect();
        try {
            const result = await client.query(`
                SELECT Account.*, Customer.Name as customername 
                FROM Account 
                JOIN Customer ON Account.CustomerID = Customer.CustomerID
            `);
            return NextResponse.json(result.rows);
        } finally {
            client.release();
        }
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });

    const client = await pool.connect();
    try {
      // Delete related transactions first
      await client.query('DELETE FROM Transaction WHERE FromAccount = $1 OR ToAccount = $1', [id]);
      
      await client.query('DELETE FROM Account WHERE AccountNo = $1', [id]);
      return NextResponse.json({ message: 'Account deleted' });
    } finally {
      client.release();
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
