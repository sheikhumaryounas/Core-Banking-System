import { NextResponse } from 'next/server';
import pool from '@/lib/db';

export async function GET() {
  try {
    const client = await pool.connect();
    try {
      // Fetch stats in parallel
      const [customerRes, accountRes, balanceRes, transactionRes] = await Promise.all([
        client.query('SELECT COUNT(*) FROM Customer'),
        client.query('SELECT COUNT(*) FROM Account'),
        client.query('SELECT SUM(Balance) FROM Account'),
        client.query('SELECT * FROM Transaction ORDER BY DateTime DESC LIMIT 5')
      ]);

      const stats = {
        totalCustomers: parseInt(customerRes.rows[0].count),
        totalAccounts: parseInt(accountRes.rows[0].count),
        totalHoldings: parseFloat(balanceRes.rows[0].sum || '0'),
        recentTransactions: transactionRes.rows
      };

      return NextResponse.json(stats);
    } finally {
      client.release();
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
