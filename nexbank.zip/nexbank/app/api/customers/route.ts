import { NextResponse } from 'next/server';
import pool from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { name, cnic, contact } = await request.json();
    const client = await pool.connect();
    try {
      const result = await client.query(
        'INSERT INTO Customer (Name, CNIC, Contact) VALUES ($1, $2, $3) RETURNING *',
        [name, cnic, contact]
      );
      return NextResponse.json(result.rows[0], { status: 201 });
    } finally {
      client.release();
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function GET() {
    try {
        const client = await pool.connect();
        try {
            const result = await client.query('SELECT * FROM Customer');
            return NextResponse.json(result.rows);
        } finally {
            client.release();
        }
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });

    const client = await pool.connect();
    try {
      // Find all accounts for this customer
      const accounts = await client.query('SELECT AccountNo FROM Account WHERE CustomerID = $1', [id]);
      const accountIds = accounts.rows.map(r => r.accountno);
      
      if (accountIds.length > 0) {
        // Delete transactions for these accounts
        await client.query('DELETE FROM Transaction WHERE FromAccount = ANY($1) OR ToAccount = ANY($1)', [accountIds]);
      }

      await client.query('DELETE FROM Customer WHERE CustomerID = $1', [id]);
      return NextResponse.json({ message: 'Customer deleted' });
    } finally {
      client.release();
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
